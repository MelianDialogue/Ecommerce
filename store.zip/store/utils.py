from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import numpy as np

def segment_customers(customer_data):
    X = np.array([[customer['age'], customer['income'], customer['spending_score']] for customer in customer_data])

    
    kmeans = KMeans(n_clusters=3, random_state=42)
    segments = kmeans.fit_predict(X)

    return segments.tolist()

def predict_churn(customer_features, churn_target):
    
    X = np.array([[customer['age'], customer['income'], customer['spending_score']] for customer in customer_features])
    y = np.array(churn_target)

    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

   
    model = LogisticRegression(random_state=42)

   
    model.fit(X_train, y_train)

  
    churn_probabilities = model.predict_proba(X_test)[:, 1]

    return churn_probabilities.tolist()  # Convert numpy array to list for JSON serialization

